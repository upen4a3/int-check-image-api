create view user_memo_posted_txn_view as
select `ua`.`user_id`                                                                                        AS `user_id`,
       `ua`.`id`                                                                                             AS `user_account_id`,
       `ua`.`account_id`                                                                                     AS `account_id`,
       `t`.`id`                                                                                              AS `transaction_id`,
       `t`.`txn_type`                                                                                        AS `txn_type`,
       (case
          when (`t`.`origination_date` is not null) then `t`.`origination_date`
          else `t`.`post_date` end)                                                                          AS `post_date`,
       `t`.`posting_seq`                                                                                     AS `posting_seq`,
       `t`.`name`                                                                                            AS `description`,
       `t`.`memo`                                                                                            AS `memo`,
       `t`.`amount`                                                                                          AS `amount`,
       `t`.`name`                                                                                            AS `original_name`,
       `t`.`created_ts`                                                                                      AS `created_ts`,
       `t`.`updated_ts`                                                                                      AS `updated_ts`
from (`d3`.`d3_transaction_memo` `t`
       join `d3`.`user_account` `ua` on ((`t`.`account_id` = `ua`.`account_id`)))
where ((`ua`.`deleted` = FALSE) and (`ua`.`associated` = TRUE));

