create view user_transaction_view as select `ua`.`user_id`                                               AS `user_id`,
                                            `ua`.`id`                                                    AS `user_account_id`,
                                            `ua`.`nickname`                                              AS `account_nickname`,
                                            `ua`.`account_id`                                            AS `account_id`,
                                            `t`.`id`                                                     AS `transaction_id`,
                                            `t`.`txn_type`                                               AS `txn_type`,
                                            `t`.`post_date`                                              AS `post_date`,
                                            `t`.`posting_seq`                                            AS `posting_seq`,
                                            `t`.`pending`                                                AS `pending`,
                                            `ut`.`id`                                                    AS `user_transaction_id`,
                                            `ua`.`hidden`                                                AS `hidden`,
                                            `ua`.`excluded`                                              AS `excluded`,
                                            coalesce(`ut`.`is_split`, FALSE)                             AS `is_split`,
                                            coalesce(`ut`.`category_id`, `t`.`category_id`)              AS `category_id`,
                                            coalesce(`ut`.`user_description`, `t`.`renamed`, `t`.`name`) AS `description`,
                                            coalesce(`ut`.`user_memo`, `t`.`memo`)                       AS `memo`,
                                            `ut`.`categorization_rule_id`                                AS `categorization_rule_id`,
                                            `ut`.`renaming_rule_id`                                      AS `renaming_rule_id`,
                                            `t`.`amount`                                                 AS `amount`,
                                            `t`.`checknum`                                               AS `checknum`,
                                            `t`.`image_id`                                               AS `image_id`,
                                            `t`.`name`                                                   AS `original_name`,
                                            `t`.`confirmation_number`                                    AS `confirmation_number`,
                                            `t`.`created_ts`                                             AS `created_ts`,
                                            (case
                                               when ((`ut`.`updated_ts` is not null) and
                                                     (`ut`.`updated_ts` > `t`.`updated_ts`)) then `ut`.`updated_ts`
                                               else `t`.`updated_ts` end)                                AS `updated_ts`
                                     from ((`d3`.`d3_transaction` `t` join `d3`.`user_account` `ua` on ((`t`.`account_id` = `ua`.`account_id`)))
                                            left join `d3`.`user_transaction` `ut`
                                                      on (((`t`.`id` = `ut`.`transaction_id`) and
                                                           (`ua`.`user_id` = `ut`.`user_id`))))
                                     where ((`ua`.`deleted` = FALSE) and (`ua`.`associated` = TRUE))
                                     union all
                                     select `ua`.`user_id`               AS `user_id`,
                                            `ua`.`id`                    AS `user_account_id`,
                                            `ua`.`nickname`              AS `account_nickname`,
                                            `ua`.`account_id`            AS `account_id`,
                                            `t`.`id`                     AS `transaction_id`,
                                            `t`.`txn_type`               AS `txn_type`,
                                            (case
                                               when (`t`.`origination_date` is not null) then `t`.`origination_date`
                                               else `t`.`post_date` end) AS `post_date`,
                                            `t`.`posting_seq`            AS `posting_seq`,
                                            1                            AS `pending`,
                                            NULL                         AS `user_transaction_id`,
                                            `ua`.`hidden`                AS `hidden`,
                                            `ua`.`excluded`              AS `excluded`,
                                            0                            AS `is_split`,
                                            NULL                         AS `category_id`,
                                            `t`.`name`                   AS `description`,
                                            `t`.`memo`                   AS `memo`,
                                            NULL                         AS `categorization_rule_id`,
                                            NULL                         AS `renaming_rule_id`,
                                            `t`.`amount`                 AS `amount`,
                                            NULL                         AS `checknum`,
                                            NULL                         AS `image_id`,
                                            `t`.`name`                   AS `original_name`,
                                            `t`.`confirmation_number`    AS `confirmation_number`,
                                            `t`.`created_ts`             AS `created_ts`,
                                            `t`.`updated_ts`             AS `updated_ts`
                                     from (`d3`.`d3_transaction_memo` `t`
                                            join `d3`.`user_account` `ua` on ((`t`.`account_id` = `ua`.`account_id`)))
                                     where ((`ua`.`deleted` = FALSE) and (`ua`.`associated` = TRUE));

